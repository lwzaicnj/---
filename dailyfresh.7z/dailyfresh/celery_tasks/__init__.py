"""please input file function"""
'''
@Time    : 2018/3/9 下午2:16
@Author  : scrappy_zhang
@File    : __init__.py.py
'''