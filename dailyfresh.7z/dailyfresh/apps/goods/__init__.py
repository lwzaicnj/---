import pymysql
pymysql.install_as_MySQLdb()

default_app_config = 'goods.apps.GoodsConfig'