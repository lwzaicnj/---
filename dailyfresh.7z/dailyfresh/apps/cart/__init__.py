import pymysql
pymysql.install_as_MySQLdb()

default_app_config = 'cart.apps.CartConfig'