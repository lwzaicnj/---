import pymysql
pymysql.install_as_MySQLdb()

default_app_config = 'order.apps.OrderConfig'