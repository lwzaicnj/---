"""please input file function"""
'''
@Time    : 2018/3/9 上午8:14
@Author  : scrappy_zhang
@File    : __init__.py.py
'''