"""please input file function"""
'''
@Time    : 2018/3/12 下午4:23
@Author  : scrappy_zhang
@File    : __init__.py.py
'''