"""please input file function"""
'''
@Time    : 2018/3/11 下午8:46
@Author  : scrappy_zhang
@File    : __init__.py.py
'''